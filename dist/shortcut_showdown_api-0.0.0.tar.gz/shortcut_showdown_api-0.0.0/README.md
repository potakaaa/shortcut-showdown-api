# Shortcut Showdown API

Backend service for **Shortcut Showdown**, built with [FastAPI](https://fastapi.tiangolo.com/). It exposes a simple health check and a WebSocket endpoint for real-time messaging during gameplay.

## Features

- **REST** — `GET /` returns a JSON status payload confirming the API is up.
- **Authoritative game sessions** — `GET /game-rooms/{room_id}` returns server-owned round state (`running`/`finished`), synchronized timer fields, per-player telemetry, and end-of-round resolution.
- **Match results** — `GET /game-rooms/{room_id}/results?player_id=...` returns a stable final podium with ordered placements, telemetry, winner/draw metadata, and the end reason/time for finished matches.
- **Authoritative player actions** — `POST /game-rooms/{room_id}/attempts` validates attempts server-side and updates room state deterministically.
- **Rematch flow** — `POST /game-rooms/{room_id}/rematch` creates a fresh lobby for the same live roster once the match is finished, so the next round can start without manual re-join.
- **Authoritative player identity** — `PATCH /players/{player_id}` stores a server-known callsign for an active WebSocket player, and lobby responses return resolved player identities instead of bare ids.
- **WebSockets** — `WS /ws` accepts connections, assigns a `player_id`, and speaks a versioned JSON envelope for lobby and gameplay events.

Gameplay determinism notes:
- Challenge RNG is server-side and seeded by room id, so all players in a room receive the same objective sequence.
- Timeout/forfeit tie-breaking order is deterministic: highest objective index, then highest accuracy, then highest WPM, then lexicographically smallest player id.
- Bots/AI players are not implemented.

## Player Identity

Every connected client receives a stable `player_id` from `WS /ws`. After connecting, clients should set a display name with:

```http
PATCH /players/{player_id}
{
  "display_name": "OPERATOR_01"
}
```

Rules for `display_name`:
- Maximum length: 24 characters
- Allowed characters: letters, numbers, spaces, `_`, and `-`
- Leading and trailing whitespace is trimmed before validation and storage
- Duplicate display names are allowed
- Display names can be updated while a player is in a lobby

Validation errors use machine-readable `detail` values:
- `display_name_empty`
- `display_name_too_long`
- `display_name_invalid_characters`
- `player_not_found`

Lobby payloads return resolved player entries in join order:

```json
{
  "id": "K7M4QZ1",
  "players": [
    {"player_id": "player-a", "display_name": "OPERATOR_01"},
    {"player_id": "player-b", "display_name": "MAVERICK"}
  ],
  "status": "waiting"
}
```

If a player has not set a display name yet, the API falls back to their `player_id` in lobby responses.

## WebSocket Protocol

The recommended realtime path is a versioned envelope with `v`, `type`, and `payload`.

```json
{
  "v": 1,
  "type": "join_lobby",
  "payload": {
    "lobby_id": "K7M4QZ1",
    "player_id": "player-a"
  }
}
```

The server keeps compatibility aliases during the migration window:
- `event` mirrors `type`
- top-level payload fields are flattened for older clients
- raw text still echoes back as `message`

Supported client events:
- `join_lobby` subscribes the socket to a lobby and returns a `lobby_snapshot`
- `join_room` subscribes the socket to a room and returns a `room_snapshot`
- `sync_state` returns the current `game_state_sync` snapshot for a room
- `input` or `attempt` forwards gameplay attempts to the authoritative engine

Lobby and room broadcasts use the same envelope:

```json
{
  "v": 1,
  "type": "lobby_updated",
  "payload": {
    "lobby_id": "K7M4QZ1",
    "change": "joined",
    "actor_player_id": "player-b",
    "lobby": {
      "id": "K7M4QZ1",
      "players": [
        {"player_id": "player-a", "display_name": "OPERATOR_01"},
        {"player_id": "player-b", "display_name": "MAVERICK"}
      ],
      "status": "full"
    }
  }
}
```

Gameplay events remain push-based over the same socket. The current server-driven events are `challenges`, `game_state_update`, `progress_update`, `penalty`, `attempt_result`, and `game_result`. The web app should treat WebSocket as the primary live channel and fall back to `GET /lobbies/{id}` or `GET /game-rooms/{id}` only when it needs a fresh snapshot after reconnect or an error response.

## Match Results And Rematch

Once a room finishes, clients can fetch the final leaderboard with:

```http
GET /game-rooms/{room_id}/results?player_id={your-player-id}
```

The results payload includes:
- The room id for the match
- `you_player_id` so the UI can highlight the current player
- Ordered `placements[]` with `player_id`, `display_name`, `place`, WPM, accuracy, progress, attempts, and finish metadata
- `end_reason`, `ended_at`, `winner_player_id`, and `draw`

Ranking is deterministic. The server orders placements by highest objective index, then highest accuracy, then highest WPM, then lexicographically smallest player id. Ties are therefore stable and reproducible.

Rematch creates a new lobby with the same roster:

```http
POST /game-rooms/{room_id}/rematch
{
  "player_id": "player-a"
}
```

Rules:
- The rematch request only succeeds once the match is finished.
- The current live roster must still match the finished match roster.
- If a player disconnects or leaves before rematch, the server rejects the request so the app does not start a partial rematch.
- The response returns the next lobby id so the client can route to `/lobby?id=...`.

Configuration (host, port, environment) is driven by environment variables and an optional `.env` file. See `.env.example` for supported keys.

## Requirements

- Python 3.11+ (recommended; match your deployment target)
- Dependencies listed in `requirements.txt`

## Setup

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # adjust HOST, PORT, ENVIRONMENT as needed
```

## Run locally

```bash
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Or:

```bash
python -m app.main
```

Interactive docs: `http://127.0.0.1:8000/docs` (when the server is running).

## Tests

```bash
pytest -q -o "addopts= "
```

## 👥 Team

<div align="center">

<table>
<tr>
<td align="center" width="50%" valign="top">
  <img src="https://github.com/hdmGOAT.png" width="88" height="88" alt="Hans Matthew Del Mundo" /><br />
  <strong>Hans Matthew Del Mundo</strong><br />
  <a href="https://github.com/hdmGOAT"><kbd>@hdmGOAT</kbd></a>
</td>
<td align="center" width="50%" valign="top">
  <img src="https://github.com/potakaaa.png" width="88" height="88" alt="Gerald Helbiro Jr." /><br />
  <strong>Gerald Helbiro Jr.</strong><br />
  <a href="https://github.com/potakaaa"><kbd>@potakaaa</kbd></a>
</td>
</tr>
<tr>
<td align="center" width="50%" valign="top">
  <img src="https://github.com/areeesss.png" width="88" height="88" alt="Vin Marcus Gerebise" /><br />
  <strong>Vin Marcus Gerebise</strong><br />
  <a href="https://github.com/areeesss"><kbd>@areeesss</kbd></a>
</td>
<td align="center" width="50%" valign="top">
  <img src="https://github.com/unripelo.png" width="88" height="88" alt="Ira Chloie Narisma" /><br />
  <strong>Ira Chloie Narisma</strong><br />
  <a href="https://github.com/unripelo"><kbd>@unripelo</kbd></a>
</td>
</tr>
</table>

</div>
